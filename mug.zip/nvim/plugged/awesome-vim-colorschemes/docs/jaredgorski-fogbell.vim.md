![fogbell](https://github.com/jaredgorski/fogbell.vim/raw/master/.media/fogbell_cover.jpg)
![fogbell](https://github.com/jaredgorski/fogbell.vim/raw/master/.media/fogbell.png)
