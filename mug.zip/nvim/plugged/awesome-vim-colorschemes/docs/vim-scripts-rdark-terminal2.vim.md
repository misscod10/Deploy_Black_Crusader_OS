This is a mirror of http://www.vim.org/scripts/script.php?script_id=4970

rdark-terminal2 modifies color for CursorLine, Type, Special, ColorColumn and IncSearch to enhance visibility for Dark Pastels. It is based on rdark-terminal of Lukas Grässlin (http://www.vim.org/scripts/script.php?script_id=3202) which ported the rdark colorscheme for 256 colors (http://www.vim.org/scripts/script.php?script_id=1732).

