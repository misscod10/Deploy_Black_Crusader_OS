import sys

print("this goes to stdout")

sys.stderr.write("foo\n")

# exit(0)
exit(1)
