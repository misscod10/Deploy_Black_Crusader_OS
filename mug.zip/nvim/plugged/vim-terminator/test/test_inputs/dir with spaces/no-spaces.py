print('a file with no spaces in a dir with spaces')
