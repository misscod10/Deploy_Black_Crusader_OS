print('file with spaces in a dir with spaces')
