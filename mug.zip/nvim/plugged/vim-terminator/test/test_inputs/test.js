

// In[1]:

for (i=1; i<10; i++){
    console.log(i)
}

// In[1]:

console.log('delimiter 2')

// In[1]:

console.log('delimiter 3')

