
-- --
A = 12

for i = 1, 10, 2 do
    io.write(i, '\n')
end

io.write("test")

-- --
