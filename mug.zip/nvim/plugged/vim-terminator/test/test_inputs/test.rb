
$stdout.sync = true

# -- 

for i in 1..10 do
  puts "Hello #{i}"
  sleep(0.2)
end

# -- 

puts "Delimiter 2"

# -- 
