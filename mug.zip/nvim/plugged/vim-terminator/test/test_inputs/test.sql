
/* In[1]: */

show databases;

/* In[2]: */
