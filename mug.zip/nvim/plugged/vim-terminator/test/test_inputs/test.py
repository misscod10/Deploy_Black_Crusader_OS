
#from time import sleep

## In[1]:

#for i in range(10):
#    print('hello world', i)
#    #print()
#    sleep(0.1)

## In[1]:

#print('stuff in delimiter 2')
print('hello world')
