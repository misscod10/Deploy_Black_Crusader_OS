
let message: string = 'Hello, World!';

var i: number;

for (i=1; i<10; i++){
    console.log(message, i)
}
